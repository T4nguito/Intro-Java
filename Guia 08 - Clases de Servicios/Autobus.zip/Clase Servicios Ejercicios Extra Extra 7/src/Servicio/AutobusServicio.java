/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Autobus;
import java.util.Scanner;

/**
 *
 * @author mpssn
 */
public class AutobusServicio {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    Autobus a = new Autobus();

//     private String identificacion;
//    private int capMaxPasaj;
//    private int capActualPasaj;
//    private int cantParad;
    
    
    public Autobus crearAutobus() {
        System.out.println("Ingrese la identificacion del autobus: ");
        a.setIdentificacion(leer.next());
        System.out.println("Ingrese capacidad maxima de pasajeros: ");
        a.setCapMaxPasaj(leer.nextInt());
        System.out.println("Ingrese cantidad de paradas: ");
        a.setCantParad(leer.nextInt());
        return a;
    }

    public void inicioRecorrido(int cantPersonas) {

        if (cantPersonas >= a.getCapMaxPasaj()) {
            System.out.println("Quedaron afuera: " + (cantPersonas - a.getCapMaxPasaj()) + " pasajeros");
            System.out.println("No pueden subir mas personas");
            a.setCapActualPasaj(0);
        } else {
            a.setCapActualPasaj(a.getCapMaxPasaj() - cantPersonas);
            System.out.println("Quedan " + a.getCapActualPasaj() + " asientos disponibles");
        }
    }

    public void finRecorrido() {
        a.setCapActualPasaj(a.getCapMaxPasaj());
        System.out.println("La disponibilidad actual es: " + a.getCapActualPasaj());    
    }

    public void subirPasajeros(int cantPersonas, int parada) {

        if (parada == 1) {
            inicioRecorrido(cantPersonas);
        } else if (parada == a.getCantParad()) {
            System.out.println("Fin de recorrido");
        } else {
            System.out.println("Cuantas personas estan viajando?: ");
            a.setCapActualPasaj(a.getCapMaxPasaj() - leer.nextInt());
            if (cantPersonas >= a.getCapMaxPasaj()) {
                System.out.println("Quedaron afuera: " + (cantPersonas - a.getCapMaxPasaj()) + " pasajeros");
                System.out.println("No pueden subir mas personas");
                a.setCapActualPasaj(0);
            } else {
                a.setCapActualPasaj(a.getCapMaxPasaj() - cantPersonas);
                System.out.println("Quedan " + a.getCapActualPasaj() + " asientos disponibles");
            }
        }
    }

    public void bajarPasajeros(int cantPersonas, int parada){
        if (parada == 1) {
            System.out.println("Inicio del recorrido");
        } else if (parada == a.getCantParad()) {
            System.out.println("Fin de recorrido");
            finRecorrido();
        } else {
            System.out.println("Cuantas personas estan viajando?: "); 
            int personasViajando=leer.nextInt();
            if (cantPersonas >= personasViajando) {
                System.out.println("No hay tantos pasajeros para bajar: ");                
                a.setCapActualPasaj(a.getCapMaxPasaj());
            } else {
                a.setCapActualPasaj(a.getCapMaxPasaj()-personasViajando+cantPersonas);
                System.out.println("Quedan " + a.getCapActualPasaj() + " asientos disponibles");
            }
        
                }
    
        
    
    
    }
}
