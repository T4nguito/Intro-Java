/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author mpssn
 */
public class Autobus {
    
    private String identificacion;
    private int capMaxPasaj;
    private int capActualPasaj;
    private int cantParad;

    public Autobus() {
    }

    public Autobus(String identificacion, int capMaxPasaj, int capActualPasaj, int cantParad) {
        this.identificacion = identificacion;
        this.capMaxPasaj = capMaxPasaj;
        this.capActualPasaj = capActualPasaj;
        this.cantParad = cantParad;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public int getCapMaxPasaj() {
        return capMaxPasaj;
    }

    public void setCapMaxPasaj(int capMaxPasaj) {
        this.capMaxPasaj = capMaxPasaj;
    }

    public int getCapActualPasaj() {
        return capActualPasaj;
    }

    public void setCapActualPasaj(int capActualPasaj) {
        this.capActualPasaj = capActualPasaj;
    }

    public int getCantParad() {
        return cantParad;
    }

    public void setCantParad(int cantParad) {
        this.cantParad = cantParad;
    }
    

   
}
