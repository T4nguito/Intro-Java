/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase.servicios.ejercicios.extra.extra.pkg7;

import Servicio.AutobusServicio;

/**
 *
 * @author mpssn
 */
public class ClaseServiciosEjerciciosExtraExtra7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        AutobusServicio as = new AutobusServicio();
        
        as.crearAutobus();
        
        
        as.subirPasajeros(10, 1);
        
        as.bajarPasajeros(5, 9);
        
        as.finRecorrido();
        
        
    }
    
}
