public class Triangulo extends Figura{

    private double radio;

    public Triangulo() {
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public Triangulo(double x, double y, double radio) {
        super(x, y);
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        double pi=3.14;
        double result = pi * radio * radio ;
        return result;
    }
}
