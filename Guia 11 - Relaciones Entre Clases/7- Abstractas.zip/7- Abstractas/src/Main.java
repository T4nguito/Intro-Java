public class Main {
    public static void main(String[] args) {
        Triangulo t = new Triangulo();
        t.setRadio(3);
        double area = t.calcularArea();
        System.out.println("El area es: " + area);
    }
}