
package Entidades;

public class Perro extends Animal {

    @Override
    public void hacerRuido() {
        System.out.println("Guuaaauuu");
    }
    
    
    
}
