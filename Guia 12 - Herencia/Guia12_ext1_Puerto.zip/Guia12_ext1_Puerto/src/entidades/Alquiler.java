/*
    En un puerto se alquilan amarres para barcos de distinto tipo. Para cada Alquiler se guarda: el
    nombre, documento del cliente, la fecha de alquiler, fecha de devoluci�n, la posici�n del
    amarre y el barco que lo ocupar�.

    Un Barco se caracteriza por: su matr�cula, su eslora en metros y a�o de fabricaci�n.

    Sin embargo, se pretende diferenciar la informaci�n de algunos tipos de barcos especiales:
        ? N�mero de m�stiles para veleros.
        ? Potencia en CV para barcos a motor.
        ? Potencia en CV y n�mero de camarotes para yates de lujo.

    Un alquiler se calcula multiplicando el n�mero de d�as de ocupaci�n (calculado con la fecha de
    alquiler y devoluci�n), por un valor m�dulo de cada barco (obtenido simplemente
    multiplicando por 10 los metros de eslora).

    En los barcos de tipo especial el m�dulo de cada barco se calcula sacando el m�dulo normal y
    sum�ndole el atributo particular de cada barco. En los veleros se suma el n�mero de m�stiles,
    en los barcos a motor se le suma la potencia en CV y en los yates se suma la potencia en CV y
    el n�mero de camarotes.

    Utilizando la herencia de forma apropiada, deberemos programar en Java, las clases y los
    m�todos necesarios que permitan al usuario elegir el barco que quiera alquilar y mostrarle el
    precio final de su alquiler.
 */
package entidades;

import java.util.Date;
import entidades.Barco;

/**
 *
 * @author Juan / Marcela XD
 */
public class Alquiler {
    
    private String nombre;
    private int DNI;
    private Date fechaAlquiler, fechaDevolucion;
    private String posicion;
    private Barco barco;

    public Alquiler() {
    }

    public Alquiler(String nombre, int DNI, Date fechaAlquiler, Date fechaDevolucion, String posicion, Barco barco) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.fechaAlquiler = fechaAlquiler;
        this.fechaDevolucion = fechaDevolucion;
        this.posicion = posicion;
        this.barco = barco;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public Date getFechaAlquiler() {
        return fechaAlquiler;
    }

    public void setFechaAlquiler(Date fechaAlquiler) {
        this.fechaAlquiler = fechaAlquiler;
    }

    public Date getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public Barco getBarco() {
        return barco;
    }

    public void setBarco(Barco barco) {
        this.barco = barco;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\n" + "DNI: " + DNI + "\n" + "Fecha de Alquiler: " + fechaAlquiler + "\n" + "Fecha de Devolucion: " + fechaDevolucion + "\n" + "Muelle: " + posicion + "\n" + "\n" + barco.toString();
    }
    
    
}
