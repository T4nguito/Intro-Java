/*
    En un puerto se alquilan amarres para barcos de distinto tipo. Para cada Alquiler se guarda: el
    nombre, documento del cliente, la fecha de alquiler, fecha de devoluci�n, la posici�n del
    amarre y el barco que lo ocupar�.

    Un Barco se caracteriza por: su matr�cula, su eslora en metros y a�o de fabricaci�n.

    Sin embargo, se pretende diferenciar la informaci�n de algunos tipos de barcos especiales:
        ? N�mero de m�stiles para veleros.
        ? Potencia en CV para barcos a motor.
        ? Potencia en CV y n�mero de camarotes para yates de lujo.

    Un alquiler se calcula multiplicando el n�mero de d�as de ocupaci�n (calculado con la fecha de
    alquiler y devoluci�n), por un valor m�dulo de cada barco (obtenido simplemente
    multiplicando por 10 los metros de eslora).

    En los barcos de tipo especial el m�dulo de cada barco se calcula sacando el m�dulo normal y
    sum�ndole el atributo particular de cada barco. En los veleros se suma el n�mero de m�stiles,
    en los barcos a motor se le suma la potencia en CV y en los yates se suma la potencia en CV y
    el n�mero de camarotes.

    Utilizando la herencia de forma apropiada, deberemos programar en Java, las clases y los
    m�todos necesarios que permitan al usuario elegir el barco que quiera alquilar y mostrarle el
    precio final de su alquiler.
 */
package entidades;

/**
 *
 * @author Juan / Marcela XD
 */
public class YateLujo extends BarcoMotor {
    
    private int numeroCamarotes;

    public YateLujo() {
    }

    public YateLujo(int numeroCamarotes, int potenciaCV, String matricula, double eslora, int anioFabricacion) {
        super(potenciaCV, matricula, eslora, anioFabricacion);
        this.numeroCamarotes = numeroCamarotes;
        this.tipo = "Yate de Lujo";
    }

    @Override
    public void valorModulo() {
        super.valorModulo();
        this.valorModulo += (numeroCamarotes * 50);
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "Cantidad de Camarotes: " + numeroCamarotes;
    }

    
    
}
