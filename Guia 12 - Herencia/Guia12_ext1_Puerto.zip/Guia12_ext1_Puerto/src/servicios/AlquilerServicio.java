/*
    En un puerto se alquilan amarres para barcos de distinto tipo. Para cada Alquiler se guarda: el
    nombre, documento del cliente, la fecha de alquiler, fecha de devoluci�n, la posici�n del
    amarre y el barco que lo ocupar�.

    Un Barco se caracteriza por: su matr�cula, su eslora en metros y a�o de fabricaci�n.

    Sin embargo, se pretende diferenciar la informaci�n de algunos tipos de barcos especiales:
        ? N�mero de m�stiles para veleros.
        ? Potencia en CV para barcos a motor.
        ? Potencia en CV y n�mero de camarotes para yates de lujo.

    Un alquiler se calcula multiplicando el n�mero de d�as de ocupaci�n (calculado con la fecha de
    alquiler y devoluci�n), por un valor m�dulo de cada barco (obtenido simplemente
    multiplicando por 10 los metros de eslora).

    En los barcos de tipo especial el m�dulo de cada barco se calcula sacando el m�dulo normal y
    sum�ndole el atributo particular de cada barco. En los veleros se suma el n�mero de m�stiles,
    en los barcos a motor se le suma la potencia en CV y en los yates se suma la potencia en CV y
    el n�mero de camarotes.

    Utilizando la herencia de forma apropiada, deberemos programar en Java, las clases y los
    m�todos necesarios que permitan al usuario elegir el barco que quiera alquilar y mostrarle el
    precio final de su alquiler.
 */
package servicios;

import entidades.Alquiler;
import entidades.Barco;
import entidades.BarcoMotor;
import entidades.Velero;
import entidades.YateLujo;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Juan / Marcela XD
 */
public class AlquilerServicio {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    private String[][] puertoPosiciones = new String[8][6];
    ArrayList<Barco> listaBarcos = new ArrayList<>();
    ArrayList<Alquiler> listaAlquileres = new ArrayList<>();

    public void generarPuerto() {

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 6; j++) {
                if (j % 2 != 0) {
                    puertoPosiciones[i][j] = "|| " + (char) ('A' + j) + (8 - i) + " ";    // Creamos el puerto. Cada amarre representado por una Letra + Numero + Espacio.
                } else {
                    puertoPosiciones[i][j] = "          " + (char) ('A' + j) + (8 - i) + " ";
                }
            }
        }
    }

    public void mostrarPuerto() {

        for (String[] fila : puertoPosiciones) {

            for (String amarre : fila) {
                if (amarre.contains("X")) {        // Si el amarre contiene una "X"

                    System.out.print(amarre);   // Mostramos cada amarre sin saltar (sin espacio)

                } else {
                    System.out.print(amarre + " ");   // Mostramos cada amarre sin saltar m�s un espacio
                }
            }
            System.out.println("");
        }
    }

    public void generarBarcos() {   // Cargamos 4 barcos iniciales

        listaBarcos.add(new Barco("1221ABCD", 5, 2023));
        listaBarcos.add(new Velero(1, "1331ABCD", 12, 2023));
        listaBarcos.add(new BarcoMotor(30, "1441ABCD", 10, 2022));
        listaBarcos.add(new YateLujo(2, 60, "1551ABCD", 20, 2022));
    }

    public void mostrarBarcos() {

        int contador = 1;

        for (Barco barco : listaBarcos) {
            System.out.println("#" + contador++);
            System.out.println("Tipo: " + barco.getTipo() + "\n" + "Matricula: " + barco.getMatricula() + "\n");    // Muestr una lista con el tipo de barco y su matricula
        }
    }

    public void registrarBarco() {

        int opcion;

        System.out.println("========== Registrar Barco ==========" + "\n");

        System.out.println("Que tipo de barco desea cargar:");

        do {
            System.out.println("1. Barco");
            System.out.println("2. Velero");
            System.out.println("3. Barco a Motor");
            System.out.println("4. Yate de Lujo");
            opcion = leer.nextInt();

            if (opcion < 1 || opcion > 4) {
                System.out.println("Error! La opcion ingresada es invalida" + "\n");
            }

        } while (opcion < 1 || opcion > 4);

        switch (opcion) {

            case 1:
                cargarBarco();
                break;

            case 2:
                cargarVelero();
                break;

            case 3:
                cargarBarcoMotor();
                break;

            case 4:
                cargarYate();
                break;
        }
    }

    public void cargarBarco() {

        System.out.println("Ingrese");
        System.out.println("Matricula del Barco:");
        String matricula = leer.next();

        System.out.println("Tama�o de Eslora:");
        double eslora = leer.nextInt();

        System.out.println("A�o de Fabricacion:");
        int anio = leer.nextInt();

        listaBarcos.add(new Barco(matricula, eslora, anio));
    }

    public void cargarVelero() {

        System.out.println("Ingrese");
        System.out.println("Matricula del Barco:");
        String matricula = leer.next();

        System.out.println("Tama�o de Eslora:");
        double eslora = leer.nextInt();

        System.out.println("A�o de Fabricacion:");
        int anio = leer.nextInt();

        System.out.println("Cantidad de Velas:");
        int velas = leer.nextInt();

        listaBarcos.add(new Velero(velas, matricula, eslora, anio));
    }

    public void cargarBarcoMotor() {

        System.out.println("Ingrese");
        System.out.println("Matricula del Barco:");
        String matricula = leer.next();

        System.out.println("Tama�o de Eslora:");
        double eslora = leer.nextInt();

        System.out.println("A�o de Fabricacion:");
        int anio = leer.nextInt();

        System.out.println("Potencia del Motor (CV):");
        int potencia = leer.nextInt();

        listaBarcos.add(new BarcoMotor(potencia, matricula, eslora, anio));
    }

    public void cargarYate() {

        System.out.println("Ingrese");
        System.out.println("Matricula del Barco:");
        String matricula = leer.next();

        System.out.println("Tama�o de Eslora:");
        double eslora = leer.nextInt();

        System.out.println("A�o de Fabricacion:");
        int anio = leer.nextInt();

        System.out.println("Potencia del Motor (CV):");
        int potencia = leer.nextInt();

        System.out.println("Cantidad de Camarotes:");
        int camarotes = leer.nextInt();

        listaBarcos.add(new YateLujo(camarotes, potencia, matricula, eslora, anio));
    }

    public void registrarAlquiler() {

        System.out.println("Nombre del cliente:");
        String name = leer.next();

        System.out.println("DNI:");
        int dni = leer.nextInt();

        System.out.println("Fecha de Inicio del Alquiler:");
        System.out.println("A�o:");
        int anio = leer.nextInt();

        System.out.println("Numero del mes:");
        int mes = leer.nextInt();

        System.out.println("Dia:");
        int dia = leer.nextInt();

        Date fechaAlquiler = new Date(anio - 1900, mes - 1, dia);

        System.out.println("Fecha Devoluci�n:");
        System.out.println("A�o:");
        anio = leer.nextInt();

        System.out.println("Numero del mes:");
        mes = leer.nextInt();

        System.out.println("Dia:");
        dia = leer.nextInt();

        Date fechaDevolucion = new Date(anio - 1900, mes - 1, dia);

        boolean repetir = true;
        String posicion;

        do {
            System.out.println("Elija una posicion (la X indica posicion ocupada)");
            mostrarPuerto();
            posicion = leer.next().toUpperCase();

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 6; j++) {
                    if (puertoPosiciones[i][j].contains(posicion) && !puertoPosiciones[i][j].contains("X")) {  // Si la posicion coincide con lo ingresado y no contiene "X"

                        posicion = puertoPosiciones[i][j];
                        puertoPosiciones[i][j] += "X";
                        repetir = false;
                        break;
                    }
                }
            }

            if (repetir) {
                System.out.println("Error! no se encontr� la posicion. Est� ocupada o no existe. Vuelva a intentarlo");
            }

        } while (repetir);

        int barco;

        do {
            repetir = true;
            saltoDeLinea();
            System.out.println("===== Seleccione el barco =====");

            mostrarBarcos();    // Mostramos la lista de Barcos

            System.out.println("Ingrese el numero:");
            barco = (leer.nextInt() - 1);   // Esta variable representa el indice/posicion del barco en el ArrayList

            if (listaBarcos.get(barco).isAmarrado()) {  // Verificamos que el barco no est� amarrado
                System.out.println("El barco ya se encuentra amarrado");
            } else {
                listaBarcos.get(barco).setAmarrado(true);   // Cambiamos el atributo del barco a True
                repetir = false;
            }

        } while (repetir);

        listaAlquileres.add(new Alquiler(name, dni, fechaAlquiler, fechaDevolucion, posicion, listaBarcos.get(barco))); // Creamos el Alquiler en la lista

        System.out.println("Registrado con Exito!");

        listaAlquileres.get(listaAlquileres.size() - 1).getBarco().valorModulo(); // Iniciamos el metodo "valorModulo()" para guardar el valor en su atributo

        System.out.println("Precio del Alquiler: $" + calcularAlquiler(listaAlquileres.size() - 1));
    }

    public int calcularDias(int indice) {

        // Creamos dos objetos Calendar
        Calendar alquiler = Calendar.getInstance();
        Calendar devolucion = Calendar.getInstance();

        // Guardamos las fechas en los objetos Calendar
        alquiler.setTime(listaAlquileres.get(indice).getFechaAlquiler());
        devolucion.setTime(listaAlquileres.get(indice).getFechaDevolucion());

        int diferenciaDias;

        // Obtenemos los dias transcurridos hasta la fecha guardada
        int diasAlquiler = alquiler.get(Calendar.DAY_OF_YEAR);
        int diasDevolucion = devolucion.get(Calendar.DAY_OF_YEAR);

        // Obtenemos el a�o de cada fecha
        int anioAlquiler = alquiler.get(Calendar.YEAR);
        int anioDevolucion = devolucion.get(Calendar.YEAR);

        if (anioAlquiler != anioDevolucion) {   // Si los a�os son diferentes
            int diasHastaFinAnioAlquiler = alquiler.getActualMaximum(Calendar.DAY_OF_YEAR) - diasAlquiler;  // Calculamos los dias restantes para finalizar el a�o
            int diasDesdeInicioAnioDevolucion = diasDevolucion - 1; // Restamos 1 porque el d�a actual tambi�n se cuenta

            diferenciaDias = diasHastaFinAnioAlquiler + diasDesdeInicioAnioDevolucion;

        } else {
            diferenciaDias = diasDevolucion - diasAlquiler;
        }

        return diferenciaDias;
    }

    public double calcularAlquiler(int indice) {

        double alquiler = calcularDias(indice) * listaAlquileres.get(indice).getBarco().getValorModulo(); // Dias de ocupacion por el "Modulo"
        return alquiler;
    }

    public int mostrarAlquileres() {
        // Mostrar lista: nombre del cliente, tipo de barco y matricula
        int contador = 1;

        System.out.println("========== Lista de Alquileres ==========");
        for (Alquiler alquiler : listaAlquileres) {
            saltoDeLinea();
            System.out.println("#" + contador++);
            System.out.println("Cliente: " + alquiler.getNombre());
            System.out.println("Barco: " + alquiler.getBarco().getTipo() + " " + alquiler.getBarco().getMatricula());
            System.out.println("Muelle: " + alquiler.getPosicion());
        }

        System.out.println("Elija el numero de alquiler:");
        int indice = leer.nextInt() - 1;

        return indice;
    }

    public void mostrarDatos(int indice) {
        System.out.println(listaAlquileres.get(indice).toString());
    }

    public void saltoDeLinea() {
        System.out.println("\n");
    }

    public void menu() {

        generarPuerto();
        generarBarcos();

        int opcion;

        System.out.println("=============== Bienvenidos al Puerto Egg ===============");
        saltoDeLinea();

        do {
            System.out.println("1. Ver Puerto");
            System.out.println("2. Ver lista de Barcos");
            System.out.println("3. Registrar Barco");
            System.out.println("4. Registrar Alquiler");
            System.out.println("5. Ver Alquiler");
            System.out.println("6. Salir");
            opcion = leer.nextInt();
            saltoDeLinea();

            switch (opcion) {
                case 1:
                    mostrarPuerto();
                    saltoDeLinea();
                    break;
                case 2:
                    mostrarBarcos();
                    saltoDeLinea();
                    break;
                case 3:
                    registrarBarco();
                    saltoDeLinea();
                    break;
                case 4:
                    registrarAlquiler();
                    saltoDeLinea();
                    break;
                case 5:
                    int indice = mostrarAlquileres();
                    saltoDeLinea();

                    do {
                        System.out.println("1. Ver Datos");
                        System.out.println("2. Ver Precio");
                        System.out.println("3. Salir");
                        opcion = leer.nextInt();
                        saltoDeLinea();

                        switch (opcion) {
                            case 1:
                                mostrarDatos(indice);
                                saltoDeLinea();
                                break;
                            case 2:
                                System.out.println("Monto de Alquiler por " + calcularDias(indice) + " dias: $" + calcularAlquiler(indice));
                                saltoDeLinea();
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Error! Opcion ingresada invalida");
                        }
                    } while (opcion != 3);
                    break;
                case 6:
                    System.out.println("=============== Gracias por usar el sistema ===============");
            }

        } while (opcion != 6);
    }
}
