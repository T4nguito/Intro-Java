
package guia12_extra_01_puerto;

import Entidades.Alquiler;
import Entidades.Barco;
import Servicios.ServicioAlquiler;

/*
 * @author Pablo Barberis
 */
public class Guia12_extra_01_puerto {

    public static void main(String[] args) {
        ServicioAlquiler sA = new ServicioAlquiler();
    }

}
