/*
    Siguiendo el ejercicio anterior, en el main vamos a crear un ArrayList de Electrodom�sticos
    para guardar 4 electrodom�sticos, ya sean lavadoras o televisores, con valores ya asignados.

    Luego, recorrer este array y ejecutar el m�todo precioFinal() en cada electrodom�stico. Se
    deber� tambi�n mostrar el precio de cada tipo de objeto, es decir, el precio de todos los
    televisores y el de las lavadoras. Una vez hecho eso, tambi�n deberemos mostrar, la suma del
    precio de todos los Electrodom�sticos. Por ejemplo, si tenemos una lavadora con un precio de
    2000 y un televisor de 5000, el resultado final ser� de 7000 (2000+5000) para
    electrodom�sticos, 2000 para lavadora y 5000 para televisor.
 */
package guia12_ej2_electrodomesticos;

import Entidades.Electrodomestico;
import Entidades.Lavadora;
import Entidades.Televisor;
import java.util.ArrayList;

/**
 *
 * @author Juan / Marcela XD
 */
public class Guia12_ej2_Electrodomesticos {

    public static void main(String[] args) {

        ArrayList<Electrodomestico> lista = new ArrayList();

        lista.add(new Lavadora(10, "Gris", 'B', 35));
        lista.add(new Televisor(40, false, "Negro", 'A', 8));
        lista.add(new Lavadora(35, "Blanco", 'C', 45));
        lista.add(new Televisor(60, true, "Negro", 'A', 14));

        int aux1 = 0, aux2 = 0, sumaLavadoras = 0, sumaTelevisores = 0;


        for (Electrodomestico elemento : lista) {

            elemento.precioFinal();

            if (elemento instanceof Lavadora) {
                System.out.println("Precio de Lavadora #" + ++aux1 + ": " + elemento.getPrecio());
                sumaLavadoras += elemento.getPrecio();
            }
        }

        System.out.println("");

        for (Electrodomestico elemento : lista) {

            if (elemento instanceof Televisor) {
                System.out.println("Precio de Televisor #" + ++aux2 + ": " + elemento.getPrecio());
                sumaTelevisores += elemento.getPrecio();
            }
        }

        System.out.println("");
        System.out.println("La suma de todas las Lavadoras es: " + sumaLavadoras);
        System.out.println("La suma de todos los Televisores es: " + sumaTelevisores);
        System.out.println("El precio total de todos los electrodomesticos es: " + (sumaLavadoras + sumaTelevisores));

    }

}
