/*
    Crear una superclase llamada Electrodom�stico con los siguientes atributos: precio, color,
    consumo energ�tico (letras entre A y F) y peso.

    Los constructores que se deben implementar son los siguientes:
    ? Un constructor vac�o.
    ? Un constructor con todos los atributos pasados por par�metro.

    Los m�todos a implementar son:
    ? M�todos getters y setters de todos los atributos.
    ? M�todo comprobarConsumoEnergetico(char letra): comprueba que la letra es correcta,
    sino es correcta usara la letra F por defecto. Este m�todo se debe invocar al crear el
    objeto y no ser� visible.
    ? M�todo comprobarColor(String color): comprueba que el color es correcto, y si no lo es,
    usa el color blanco por defecto. Los colores disponibles para los electrodom�sticos son
    blanco, negro, rojo, azul y gris. No importa si el nombre est� en may�sculas o en
    min�sculas. Este m�todo se invocar� al crear el objeto y no ser� visible.
    ? Metodo crearElectrodomestico(): le pide la informaci�n al usuario y llena el
    electrodom�stico, tambi�n llama los m�todos para comprobar el color y el consumo. Al
    precio se le da un valor base de $1000.
    ? M�todo precioFinal(): seg�n el consumo energ�tico y su tama�o, aumentar� el valor del
    precio. Esta es la lista de precios:

        LETRA   PRECIO          PESO            PRECIO
          A     $1000       Entre 1 y 19 kg      $100
          B     $800        Entre 20 y 49 kg     $500
          C     $600        Entre 50 y 79 kg     $800
          D     $500        Mayor que 80 kg     $1000
          E     $300
          F     $100

    A continuaci�n, se debe crear una subclase llamada Lavadora, con el atributo carga,
    adem�s de los atributos heredados.

    Los constructores que se implementar�n ser�n:
    ? Un constructor vac�o.
    ? Un constructor con la carga y el resto de los atributos heredados. Recuerda que debes
    llamar al constructor de la clase padre.

    Los m�todos que se implementara ser�n:
    ? M�todo get y set del atributo carga.
    ? M�todo crearLavadora (): este m�todo llama a crearElectrodomestico() de la clase
    padre, lo utilizamos para llenar los atributos heredados del padre y despu�s llenamos
    el atributo propio de la lavadora.
    ? M�todo precioFinal(): este m�todo ser� heredado y se le sumar� la siguiente
    funcionalidad. Si tiene una carga mayor de 30 kg, aumentar� el precio en $500, si la
    carga es menor o igual, no se incrementar� el precio. Este m�todo debe llamar al
    m�todo padre y a�adir el c�digo necesario. Recuerda que las condiciones que hemos
    visto en la clase Electrodom�stico tambi�n deben afectar al precio.


    Se debe crear tambi�n una subclase llamada Televisor con los siguientes atributos:
    resoluci�n (en pulgadas) y sintonizador TDT (booleano), adem�s de los atributos
    heredados.

    Los constructores que se implementar�n ser�n:
    ? Un constructor vac�o.
    ? Un constructor con la resoluci�n, sintonizador TDT y el resto de los atributos
    heredados. Recuerda que debes llamar al constructor de la clase padre.

    Los m�todos que se implementara ser�n:
    ? M�todo get y set de los atributos resoluci�n y sintonizador TDT.
    ? M�todo crearTelevisor(): este m�todo llama a crearElectrodomestico() de la clase
    padre, lo utilizamos para llenar los atributos heredados del padre y despu�s llenamos
    los atributos del televisor.
    ? M�todo precioFinal(): este m�todo ser� heredado y se le sumar� la siguiente
    funcionalidad. Si el televisor tiene una resoluci�n mayor de 40 pulgadas, se
    incrementar� el precio un 30% y si tiene un sintonizador TDT incorporado, aumentar�
    $500. Recuerda que las condiciones que hemos visto en la clase Electrodomestico
    tambi�n deben afectar al precio.


    Finalmente, en el main debemos realizar lo siguiente:
    Vamos a crear una Lavadora y un Televisor y llamar a los m�todos necesarios para mostrar
    el precio final de los dos electrodom�sticos.
 */
package Entidades;

import java.util.Scanner;

/**
 *
 * @author Juan / Marcela XD
 */
public class Electrodomestico {

    protected double precio;
    protected String color;
    protected char consumoEnergetico;
    protected double peso;

    public Electrodomestico() {
    }

    public Electrodomestico(String color, char consumoEnergetico, double peso) {
        this.precio = 1000;
        this.color = comprobarColor(color);
        this.peso = peso;
        this.consumoEnergetico = comprobarConsumoEnergetico(consumoEnergetico);
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public char getConsumoEnergetico() {
        return consumoEnergetico;
    }

    public void setConsumoEnergetico(char consumoEnergetico) {
        this.consumoEnergetico = consumoEnergetico;
    }

    public char comprobarConsumoEnergetico(char letra) {

        letra = Character.toUpperCase(letra); // Nos aseguramos que la letra/caracter est� en mayuscula

        if (letra != 'A' && letra != 'B' && letra != 'C' && letra != 'D' && letra != 'E') { // Si la letra es diferente a "A, B, C, D, E" ser� "F"
            letra = 'F';
        }

        return letra;
    }

    public String comprobarColor(String color) {

        color = color.toLowerCase();    // Pasamos la palabra a minusculas

            // Si el color es diferente a "negro, rojo, azul, gris" ser� "blanco"
        if (!color.equals("negro") && !color.equals("rojo") && !color.equals("azul") && !color.equals("gris")) {
            color = "blanco";
        }

        return color;
    }

    public void crearElectrodomestico() {

        Scanner leer = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Ingrese el color:");
        String color = leer.next();

        System.out.println("Ingrese el Consumo Energ�tico (A, B, C, D, E, F):");
        char consumo = leer.next().charAt(0);

        System.out.println("Ingrese el peso:");
        double peso = leer.nextDouble();

        this.precio = 1000;                         // Guardamos los valores en sus respectivos atributos
        this.color = comprobarColor(color);         // Guardamos el valor que retorna el metodo
        this.peso = peso;
        this.consumoEnergetico = comprobarConsumoEnergetico(consumo); // Guardamos el valor que retorna el metodo
    }

    public void precioFinal() {
/*
        - M�todo precioFinal(): seg�n el consumo energ�tico y su tama�o, aumentar� el valor del
    precio. Esta es la lista de precios:

        LETRA   PRECIO          PESO            PRECIO
          A     $1000       Entre 1 y 19 kg      $100
          B     $800        Entre 20 y 49 kg     $500
          C     $600        Entre 50 y 79 kg     $800
          D     $500        Mayor que 80 kg     $1000
          E     $300
          F     $100
*/

        switch (consumoEnergetico) {

            case 'A':
                this.precio = precio + 1000;
                break;

            case 'B':
                this.precio = precio + 800;
                break;

            case 'C':
                this.precio = precio + 600;
                break;

            case 'D':
                this.precio = precio + 500;
                break;

            case 'E':
                this.precio = precio + 300;
                break;

            case 'F':
                this.precio = precio + 100;
        }

        if (peso < 20) {
            this.precio = precio + 100;
        } else if (peso < 50) {
            this.precio = precio + 500;
        } else if (precio < 80) {
            this.precio = precio + 800;
        } else {
            this.precio = precio + 1000;
        }
    }

}
