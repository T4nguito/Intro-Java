package Entidades;

import java.util.Scanner;

public class Televisor extends Electrodomestico {

    private double resolucion;
    private boolean sintonizadorTDT = false;

    public Televisor() {
    }

    public Televisor(double resolucion, boolean sintonizador, String color, char consumoEnergetico, double peso) {
        super(color, consumoEnergetico, peso);
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizador;
    }

    public double getResolucion() {
        return resolucion;
    }

    public void setResolucion(double resolucion) {
        this.resolucion = resolucion;
    }

    public boolean isSintonizadorTDT() {
        return sintonizadorTDT;
    }

    public void setSintonizadorTDT(boolean sintonizadorTDT) {
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public void crearTelevisor() {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");

        crearElectrodomestico();

        System.out.println("Ingrese la Resolucion en pulgadas:");
        this.resolucion = leer.nextDouble();

        int opcion;

        do {
            System.out.println("El televisor tiene Sintonizador TDT incorporado?");
            System.out.println("1. SI");
            System.out.println("2. NO");
            opcion = leer.nextInt();

            if (opcion != 1 && opcion != 2) {
                System.out.println("Error! la opcion ingresada es invalida.");
            }
        } while (opcion != 1 && opcion != 2);

        if (opcion == 1) {
            this.sintonizadorTDT = true;
        }
    }

    @Override
    public void precioFinal() {
        super.precioFinal();

        if (resolucion > 40) {
            this.precio = precio * 1.3;
        }

        if (sintonizadorTDT) {
            this.precio = precio + 500;
        }
    }

}
