package Entidades;

import java.util.Scanner;

public class Lavadora extends Electrodomestico {

    private int carga;

    public Lavadora() {
    }

    public Lavadora(int carga, String color, char consumoEnergetico, double peso) {
        super(color, consumoEnergetico, peso);
        this.carga = carga;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }

    public void crearLavadora() {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        crearElectrodomestico();

        System.out.println("Ingrese la Capacidad de Carga:");
        this.carga = leer.nextInt();
    }

    @Override
    public void precioFinal() {
        super.precioFinal();
        
        if (carga > 30) {
            this.precio = precio + 500;
        }
    }

    

}
