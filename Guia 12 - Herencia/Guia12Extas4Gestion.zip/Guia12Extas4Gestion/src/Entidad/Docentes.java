package Entidad;

import java.util.Scanner;

public class Docentes extends Empleados {

    private String departamento;
    
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public Docentes() {
    }

    public Docentes(String departamento, Integer fechaAlta, Integer despacho, String nombreyapellido, Integer dni, String estado) {
        super(fechaAlta, despacho, nombreyapellido, dni, estado);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public Integer getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Integer fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public Integer getDespacho() {
        return despacho;
    }

    public void setDespacho(Integer despacho) {
        this.despacho = despacho;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return super.toString()+ "Docentes{" + "departamento=" + departamento + '}';
    }

    
    
    public void crearDocentes() {
        super.crearEmpleado();
        System.out.println("Ingrese el departamento al que pertenece: ");
        this.setDepartamento(leer.next());
    }
}
