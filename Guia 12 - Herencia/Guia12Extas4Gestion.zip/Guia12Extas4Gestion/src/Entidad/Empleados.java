package Entidad;

import java.time.LocalDate;
import java.util.Scanner;

public class Empleados extends Personas {

    protected Integer fechaAlta;

    protected Integer despacho;
    
      private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Empleados() {
    }

    public Empleados(Integer fechaAlta, Integer despacho, String nombreyapellido, Integer dni, String estado) {
        super(nombreyapellido, dni, estado);
        this.fechaAlta = fechaAlta;
        this.despacho = despacho;
    }

    public Integer getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Integer fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public Integer getDespacho() {
        return despacho;
    }

    public void setDespacho(Integer despacho) {
        this.despacho = despacho;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Empleados{" + "fechaAlta=" + fechaAlta + ", despacho=" + despacho + '}';
    }

    
    
    public void crearEmpleado() {
        super.crearPersona();
        System.out.println("Ingrese año que ingreso:  ");
        this.setFechaAlta(leer.nextInt());
        System.out.println("Ingrese el numero de despacho: ");
        this.setDespacho(leer.nextInt());
    }
}
