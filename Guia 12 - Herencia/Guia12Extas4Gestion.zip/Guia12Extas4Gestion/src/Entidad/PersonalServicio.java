package Entidad;

import java.util.Scanner;


public class PersonalServicio extends Empleados {

    private String seccion;
    
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public PersonalServicio() {
    }

    public PersonalServicio(String seccion, Integer fechaAlta, Integer despacho, String nombreyapellido, Integer dni, String estado) {
        super(fechaAlta, despacho, nombreyapellido, dni, estado);
        this.seccion = seccion;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public Integer getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Integer fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public Integer getDespacho() {
        return despacho;
    }

    public void setDespacho(Integer despacho) {
        this.despacho = despacho;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return super.toString()+ "PersonalServicio{" + "seccion=" + seccion + '}';
    }

    
    
    public void crearPersonal() {
        super.crearEmpleado();
        System.out.println("Ingrese la seccion donde trabaja: ");
        this.setSeccion(leer.next());
    }
}
