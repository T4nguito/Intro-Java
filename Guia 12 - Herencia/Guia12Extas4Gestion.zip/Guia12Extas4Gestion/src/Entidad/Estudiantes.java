package Entidad;
import java.util.Scanner;

public class Estudiantes extends Personas {

    private String curso;
    
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Estudiantes() {
    }

    public Estudiantes(String curso, String nombreyapellido, Integer dni, String estado) {
        super(nombreyapellido, dni, estado);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return super.toString()+  "Estudiantes: "+"Curso: " + curso; //To change body of generated methods, choose Tools | Templates.
    }

    

   

    
    
    public void crearEstudiantes() {
        super.crearPersona();
        System.out.println("Ingrese el curso: ");
        this.setCurso(leer.next());
    }
}
