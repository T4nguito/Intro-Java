package Entidad;

import java.util.Scanner;

public abstract class Personas {

    protected String nombreyapellido;

    protected Integer dni;

    protected String estado;
    
       private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Personas() {
    }

    public Personas(String nombreyapellido, Integer dni, String estado) {
        this.nombreyapellido = nombreyapellido;
        this.dni = dni;
        this.estado = estado;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Personas{" + "nombreyapellido=" + nombreyapellido + ", dni=" + dni + ", estado=" + estado + '}';
    }

    
    
    public void crearPersona() {
        System.out.println("Ingrese el nombre y apellido");
        this.setNombreyapellido(leer.next());
        System.out.println("Ingrese numero de DNI");
        this.setDni(leer.nextInt());
        System.out.println("Ingrese el estado civil");
        this.setEstado(leer.next());
    }
}
