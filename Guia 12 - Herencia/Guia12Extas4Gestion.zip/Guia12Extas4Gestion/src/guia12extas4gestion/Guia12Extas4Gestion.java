
package guia12extas4gestion;

import Servicios.GestionServicios;


public class Guia12Extas4Gestion {

    
    public static void main(String[] args) {
        
        GestionServicios facultad = new GestionServicios();
        
        facultad.crearListaPersonas();
                
             
        
        
    }
    
}
