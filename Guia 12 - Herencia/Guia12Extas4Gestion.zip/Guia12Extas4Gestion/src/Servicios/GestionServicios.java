package Servicios;

import Entidad.Docentes;
import Entidad.Estudiantes;
import Entidad.PersonalServicio;
import Entidad.Personas;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class GestionServicios {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Personas> ListaPersonas = new ArrayList<>();

    public void crearListaPersonas() {

        boolean bandera = true;
        boolean bandera1 = true;
        do {
            System.out.println("Bienvenido! Menu Gestion Facultad........");
            System.out.println("1 - Cargar estudiantes...");
            System.out.println("2 - Cargar docentes...");
            System.out.println("3 - Cargar personal de servicio...");
            System.out.println("4 - Mostrar lista...");
            System.out.println("5- Modificar datos...");
            System.out.println("6 - Salir...");
            switch (leer.nextInt()) {
                case 1:

                    Estudiantes alumno = new Estudiantes();
                    alumno.crearEstudiantes();

                    ListaPersonas.add(alumno);
                    System.out.println("Estudiante Registrado");

                    break;
                case 2:
                    Docentes profe = new Docentes();
                    profe.crearDocentes();
                    ListaPersonas.add(profe);
                    System.out.println("Docente Registrado");
                    break;
                case 3:
                    PersonalServicio personal = new PersonalServicio();
                    personal.crearPersonal();
                    ListaPersonas.add(personal);
                    System.out.println("Personal de Servicio Registrado");
                    break;
                case 4:
                    for (Personas Lista : ListaPersonas) {
                        System.out.println(Lista.toString());
                    }
                    break;
                case 5:
                    do {
                        System.out.println("MODIFICAR DATOS........");
                        System.out.println("1 - Modificar estudiantes...");
                        System.out.println("2 - Modificar docentes...");
                        System.out.println("3 - Modificar personal de servicio...");
                        System.out.println("4 - Salir...");
                        switch (leer.nextInt()) {
                            case 1:

                                System.out.println("Estudiante Modificado");

                                break;
                            case 2:

                                System.out.println("Docente Modificado");
                            case 3:

                                System.out.println("Personal de Servicio Modificado");

                                break;
                            case 4:
                                System.out.println("Esta seguro de salir?S/N");
                                if (leer.next().equalsIgnoreCase("S")) {
                                    bandera = false;

                                }

                                break;
                            default:
                                System.out.println("Opcion incorrecta.");
                                System.out.println("Ingrese una opocion valida: ");

                        }

                    } while (bandera1);

                    break;
                case 6:
                    System.out.println("Esta seguro de salir?S/N");
                    if (leer.next().equalsIgnoreCase("S")) {
                        bandera = false;

                    }
                    break;
                default:
                    System.out.println("Opcion incorrecta.");
                    System.out.println("Ingrese una opocion valida: ");

            }

        } while (bandera);
        System.out.println("Saliendo del sistema...");
    }

}
