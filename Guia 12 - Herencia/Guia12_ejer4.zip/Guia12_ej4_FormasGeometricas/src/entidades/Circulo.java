/*
    Se plantea desarrollar un programa que nos permita calcular el �rea y el per�metro de formas
    geom�tricas, en este caso un c�rculo y un rect�ngulo. Ya que este c�lculo se va a repetir en las
    dos formas geom�tricas, vamos a crear una Interfaz, llamada calculosFormas que tendr�, los
    dos m�todos para calcular el �rea, el per�metro y el valor de PI como constante.

    Desarrollar el ejercicio para que las formas implementen los m�todos de la interfaz y se
    calcule el �rea y el per�metro de los dos. En el main se crear�n las formas y se mostrar� el
    resultado final.

    �rea circulo: PI * radio ^ 2 / Per�metro circulo: PI * di�metro.

    �rea rect�ngulo: base * altura / Per�metro rect�ngulo: (base + altura) * 2.
 */
package entidades;

/**
 *
 * @author manha
 */
public class Circulo implements calculosFormas {

    private double radio, diametro;

    public Circulo(double radio) {
        this.radio = radio;
        this.diametro = radio * 2;
    }

    @Override
    public void calcularArea() {

        double area = Math.pow((PI * radio), 2);
        System.out.println("El area del Circulo es: " + area);

    }

    @Override
    public void calcularPerimetro() {
        double perimetro = PI * diametro;
        System.out.println("El perimetro del Circulo es: " + perimetro);
    }

}
