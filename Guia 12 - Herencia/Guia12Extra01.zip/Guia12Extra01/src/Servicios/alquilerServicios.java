/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidad.Alquiler;
import Entidad.BarcoMotor;
import Entidad.Velero;
import Entidad.Yate;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Ayrton
 */
public class alquilerServicios
{

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Alquiler crearAlquiler()
    {
        System.out.println("Ingrese el nombre: ");
        String nombre = leer.next();
        System.out.println("Ingrese n documento: ");
        int dni = leer.nextInt();
        System.out.println("Ingrese la fecha de alquiler: ");
        int dia = leer.nextInt();
        int mes = leer.nextInt();
        int anio = leer.nextInt();
        Date fechaAlquiler = new Date(anio - 1900, mes - 1, dia);
        System.out.println("Ingrese la fecha de devolucion: ");
        int diaDev = leer.nextInt();
        int mesDev = leer.nextInt();
        int anioDev = leer.nextInt();
        Date fechaDevolucion = new Date(anioDev - 1900, mesDev - 1, diaDev);
        System.out.println("En que posicion se encuentra? ");
        int posicion = leer.nextInt();
        System.out.println("Que tipo de barco desea alquilar? ");
        System.out.println("1. Barco");
        System.out.println("2. Barco motor");
        System.out.println("3. Velero");
        System.out.println("4. Yate digo");

        int opcion = leer.nextInt();
        switch (opcion)
        {
            case 1:
                
                

            case 2:

            case 3:

            case 4:

                break;
            default:
                throw new AssertionError();
        }

        return new Alquiler(nombre, 0, fechaAlquiler, fechaDevolucion, 0, barco)

    }

    public int calcularDias(Alquiler alquiler)
    {
        return (int) ((alquiler.getFechaDevolucion().getTime() - alquiler.getFechaAlquiler().getTime())
                / 86400000);

        //1000ms*60s*60m*24h = 86.400.000 segun Cori
    }

    public double valorModulo(Alquiler alquiler)
    {
        double modulo = alquiler.getBarco().getEslora() * 10;

        if (alquiler.getBarco() instanceof Yate)
        {
            Yate y = (Yate) alquiler.getBarco();

            return modulo + y.getPotencia() + y.getCamarotes();

        } else if (alquiler.getBarco() instanceof BarcoMotor)
        {
            BarcoMotor bM = (BarcoMotor) alquiler.getBarco();

            return modulo + bM.getPotencia();

        } else if (alquiler.getBarco() instanceof Velero)
        {
            Velero v = (Velero) alquiler.getBarco();
            return modulo + v.getMastil();

        } else
        {

            return modulo;
        }
    }

    public double calcularAlquiler(Alquiler alquiler)
    {

        return calcularDias(alquiler) * valorModulo(alquiler);

    }

}
