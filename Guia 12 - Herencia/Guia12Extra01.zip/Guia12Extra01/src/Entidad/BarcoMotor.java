/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *Potencia en CV para barcos a motor.
 * @author Ayrton
 */
public class BarcoMotor extends Barco
{
    
    private double potencia;

    public BarcoMotor()
    {
    }

    public BarcoMotor(double potencia, String matricula, double eslora, int fabricado)
    {
        super(matricula, eslora, fabricado);
        this.potencia = potencia;
    }

    public double getPotencia()
    {
        return potencia;
    }

    public void setPotencia(double potencia)
    {
        this.potencia = potencia;
    }
    
    
    
    
}
