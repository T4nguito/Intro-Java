/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pruebas.ejercicio8guia13;

import pruebas.ejercicio8guia13.Entidades.Dos;
import pruebas.ejercicio8guia13.Entidades.Uno;

/**
 *
 * @author Alveiro Izarra
 */
public class PruebasEjercicio8Guia13 {

    // main de la clase uno
    public static void main(String[] args) {
        Uno prb = new Uno();
        try {
            System.out.println("El Valor total es: "+prb.metodo());
        } catch (Exception e) {
            System.out.println("Excepcion en metodo() " + e.getMessage()) ;
           
        }
    }

        // main de la clase dos 
//        Dos prb2 = new Dos();
//        try {
//            System.out.println(prb2.metodo());
//        } catch (Exception e) {
//            System.out.println(" Excepcion en metodo ( ) " + e.getMessage());
//
//        }
    }


