/*
Definir una Clase que contenga algún tipo de dato de tipo array y agregue el código para
generar y capturar una excepción ArrayIndexOutOfBoundsException (índice de arreglo fuera
de rango).
 */
package excepcionesej2;


public class ExcepcionesEj2 {

    
    public static void main(String[] args) {
     int [] vector ={2,5,6,7};
     try{
           System.out.println(vector[4]);  
     }catch(Exception e){
          System.out.println("el indice no existe, el error es:  " + e);
     }   
 
        
        
    }
    
}
