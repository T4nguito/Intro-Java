/*
A continuación, en la clase main hacer lo siguiente:
Crear 4 objetos de tipo Persona con distintos valores, a continuación, 
llamaremos todos los métodos para cada objeto, deberá comprobar si la persona está en su peso ideal, 
tiene sobrepeso o está por debajo de su peso ideal e indicar para cada objeto si la persona es mayor de edad.

Por último, guardaremos los resultados de los métodos calcularIMC y esMayorDeEdad en distintas variables(arrays),
para después calcular un porcentaje de esas 4 personas cuantas están por debajo de su peso, 
cuantas en su peso ideal y cuantos, por encima, y también calcularemos un porcentaje de cuantos 
son mayores de edad y cuantos menores. Para esto, podemos crear unos métodos adicionales.

 */

package ejercicio3guia8encuentros19a24;

import ejercicio3guia8encuentros19a24.Entidades.Persona;
import ejercicio3guia8encuentros19a24.Servicios.PersonaServicios;
import java.util.Scanner;

/*
 * author Alveiro Izarra
 */
public class Ejercicio3Guia8Encuentros19a24 {
    
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        PersonaServicios per = new PersonaServicios();
        System.out.println("Ingrese la Cantidad de Personas: ");
        int num = leer.nextInt();
        Persona[] vecPersonas = new Persona[num];
        boolean[] vecEME = new boolean[num];
        int[] vecIMC = new int[num];
        int contEME = 0, contNoEME = 0;
        double pesoIdeal = 0, pesoBajo = 0, sobrePeso = 0;
        for (int i = 0; i < num; i++) {
            System.out.println("");
            vecPersonas[i] = per.crearPersona();
            vecEME[i] = per.esMayorDeEdad(vecPersonas[i]);
            if (vecEME[i]) {
                System.out.println("Es Mayor de Edad");
                contEME++;
            } else {
                System.out.println("Es Menor de Edad");
                contNoEME++;
            }
            vecIMC[i] = per.calcularIMC(vecPersonas[i]);
            switch (vecIMC[i]) {
                case 1:
                    System.out.println("La Persona tiene Sobrepeso");
                    sobrePeso++;
                    System.out.println("sobrepeso = "+sobrePeso);
                    break;
                case 0:
                    System.out.println("La Persona tiene Peso Ideal");
                    pesoIdeal++;
                    System.out.println("peso ideal = "+pesoIdeal);
                    break;
                default:
                    System.out.println("La Persona tiene muy Bajo Peso");
                    pesoBajo++;
                    System.out.println("peso bajo = "+pesoBajo);
                    break;
            }
        }
        System.out.println("");
        System.out.println("Porcentaje de las Personas con Sobrepeso: " + ((sobrePeso / num) * 100) + "%");
        System.out.println("Porcentaje de las Personas con Peso Ideal: " + ((pesoIdeal / num) * 100) + "%");
        System.out.println("Porcentaje de las Personas con Bajo Peso: " + ((pesoBajo / num) * 100) + "%");
        System.out.println("");
        System.out.println(contEME + " Son Mayores de Edad.");
        System.out.println(contNoEME + " Son Menores de Edad.");
        System.out.println("");
        System.out.println("");
    }
    

}
