/*
En el paquete Servicios crear PersonaServicio con los siguientes 3 métodos:
Método esMayorDeEdad(): indica si la persona es mayor de edad. La función devuelve un booleano.

Metodo crearPersona(): el método crear persona, le pide los valores de los atributos al usuario 
y después se le asignan a sus respectivos atributos para llenar el objeto Persona. 
Además, comprueba que el sexo introducido sea correcto, es decir, H, M o O. 
Si no es correcto se deberá mostrar un mensaje

Método calcularIMC(): calculara si la persona está en su peso ideal (peso en kg/(altura^2 en mt2)). 
Si esta fórmula da por resultado un valor menor que 20, significa que la persona está por debajo de su peso ideal 
y la función devuelve un -1. 
Si la fórmula da por resultado un número entre 20 y 25 (incluidos), 
significa que la persona está en su peso ideal y la función devuelve un 0. 
Finalmente, si el resultado de la fórmula es un valor mayor que 25 significa que la persona 
tiene sobrepeso, y la función devuelve un 1.
 */

package ejercicio3guia8encuentros19a24.Servicios;

import ejercicio3guia8encuentros19a24.Entidades.Persona;
import java.util.Scanner;

/**
 *
 *author Alveiro Izarra
 */
public class PersonaServicios {
    
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public boolean esMayorDeEdad(Persona varPer) {        
        return varPer.getEdad() >= 18;
    }

    public Persona crearPersona() {
        Persona varPer = new Persona();
        System.out.println("Ingrese el Nombre de la Persona: ");
        varPer.setNombre(leer.next());
        System.out.println("Ingrese la Edad de la Persona: ");
        varPer.setEdad(leer.nextInt());
        String sexPer;
        do {
            System.out.println("Ingrese el Sexo de la Persona (M mujer, H hombre y O otro): ");
            sexPer = leer.next().toUpperCase();
            if (sexPer.equals("M") || sexPer.equals("H") || sexPer.equals("O")) {
                varPer.setSexo(sexPer);
            } else { 
                System.out.println("El Tipo de Sexo Ingresado es Incorrecto");
            }
        } while (!sexPer.equals("M") && !sexPer.equals("H") && !sexPer.equals("O"));
        System.out.println("Ingrese el Peso de la Persona: ");
        varPer.setPeso(leer.nextFloat());
        System.out.println("Ingresar la Altura de la Persona: ");
        varPer.setAltura(leer.nextFloat());
        return varPer;
    } 
    
    public int calcularIMC(Persona varPer) {
        int condicion;
        double imc = varPer.getPeso() / Math.pow(varPer.getAltura(), 2);
        if (imc < 20) {
            condicion = -1;
        } else if (imc > 26) {
            condicion = 1;
        } else {
            condicion = 0;
        }
        return condicion;
    }
}
