/*
    Ejercicio 3:

    Defina una clase llamada DivisionNumero. En el m�todo main utilice un Scanner para leer dos
    n�meros en forma de cadena. A continuaci�n, utilice el m�todo parseInt() de la clase Integer,
    para convertir las cadenas al tipo int y guardarlas en dos variables de tipo int. Por ultimo realizar
    una divisi�n con los dos numeros y mostrar el resultado.

    Ejercicio 4:

    Todas estas operaciones puede tirar excepciones a manejar, el ingreso por teclado puede
    causar una excepci�n de tipo InputMismatchException, el m�todo Integer.parseInt() si la cadena
    no puede convertirse a entero, arroja una NumberFormatException y adem�s, al dividir un
    n�mero por cero surge una ArithmeticException. Manipule todas las posibles excepciones
    utilizando bloques try/catch para las distintas excepciones
 */
package entidades;

/**
 *
 * @author Juan / Marcela xD
 */
public class DivisionNumero {

    private int num1;
    private int num2;

    public void transformarString(String numero1, String numero2) {

        this.num1 = Integer.parseInt(numero1);
        this.num2 = Integer.parseInt(numero2);
    }

    public void dividir() {

        System.out.println("La division de " + num1 + " / " + num2 + " es: " + (num1 / num2));
    }

}
