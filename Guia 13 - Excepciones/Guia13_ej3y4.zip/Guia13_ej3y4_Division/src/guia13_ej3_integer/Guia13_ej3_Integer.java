/*
    Ejercicio 3:

    Defina una clase llamada DivisionNumero. En el m�todo main utilice un Scanner para leer dos
    n�meros en forma de cadena. A continuaci�n, utilice el m�todo parseInt() de la clase Integer,
    para convertir las cadenas al tipo int y guardarlas en dos variables de tipo int. Por ultimo realizar
    una divisi�n con los dos numeros y mostrar el resultado.

    Ejercicio 4:

    Todas estas operaciones puede tirar excepciones a manejar, el ingreso por teclado puede
    causar una excepci�n de tipo InputMismatchException, el m�todo Integer.parseInt() si la cadena
    no puede convertirse a entero, arroja una NumberFormatException y adem�s, al dividir un
    n�mero por cero surge una ArithmeticException. Manipule todas las posibles excepciones
    utilizando bloques try/catch para las distintas excepciones
 */
package guia13_ej3_integer;

import entidades.DivisionNumero;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Juan / Marcela xD
 */
public class Guia13_ej3_Integer {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in).useDelimiter("\n");

        DivisionNumero dv1 = new DivisionNumero();

        try {

            System.out.println("Ingrese el valor del Primero Numero:");
            String num1 = leer.next();

            System.out.println("Ingrese el valor del Segundo Numero:");
            String num2 = leer.next();

            dv1.transformarString(num1, num2);
            dv1.dividir();

        } catch (NumberFormatException a) {
            System.out.println("===== Error: el tipo de dato ingresado no puede transformar a Entero =====");
            
        } catch (InputMismatchException a) {
            System.out.println("===== Error al ingresar un tipo de dato no esperado =====");
            
        } catch (ArithmeticException a) {
            System.out.println("===== Error: No se puede dividir en 0 (cero) =====");
        }

    }
}
