/*
Defina una clase llamada DivisionNumero. En el método main utilice un Scanner para leer dos
números en forma de cadena. A continuación, utilice el método parseInt() de la clase Integer,
para convertir las cadenas al tipo int y guardarlas en dos variables de tipo int. Por ultimo realizar
una división con los dos numeros y mostrar el resultado.
 */
package excepcionesg13eje3;

import Entidad.DivisionNumero;
import static java.lang.Integer.parseInt;
import java.util.Scanner;


public class ExcepcionesG13Eje3 {

    public static void main(String[] args) {
        DivisionNumero division = new DivisionNumero();
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el numero A");
        division.setNumA(sc.next());
        System.out.println("Ingrese el numero B");
        division.setNumB(sc.next());
        
        try{
            int numero1 = Integer.parseInt(division.getNumA());
        int numero2 = Integer.parseInt(division.getNumB());
        
       double div= (numero1/numero2); 
        System.out.println("el resultado de la division es: " + div); 
        }catch(NumberFormatException e){
            System.out.println(" No se ingreso un numero: " + e);
        }catch(Exception e){
            System.out.println("la excepcion es de tipo: " + e);
        }
       
        
    }
    
}
