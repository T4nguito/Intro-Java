/*
Defina una clase llamada DivisionNumero. En el método main utilice un Scanner para leer dos
números en forma de cadena. A continuación, utilice el método parseInt() de la clase Integer,
para convertir las cadenas al tipo int y guardarlas en dos variables de tipo int. Por ultimo realizar
una división con los dos numeros y mostrar el resultado.
 */
package Entidad;


public class DivisionNumero {
    
   public String numA;
   public String numB;

    public DivisionNumero(String numA, String numB) {
        this.numA = numA;
        this.numB = numB;
    }

    public DivisionNumero() {
    }

    
    public String getNumA() {
        return numA;
    }

    public void setNumA(String numA) {
        this.numA = numA;
    }

    public String getNumB() {
        return numB;
    }

    public void setNumB(String numB) {
        this.numB = numB;
    }
   
    
    
}
