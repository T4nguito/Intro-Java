/*
Escribe un programa que encuentre el número entero más grande que 
se puede representar con n bits (donde n es un número entero que el usuario ingresa).
 */
package guia9_extra_extra_integer_3;

import Servicios.NBitsServicio;
import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author Salvador Caldarella
 */
public class Guia9_extra_extra_Integer_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese un numero para calcular el numero de bits");
        int n = leer.nextInt();
        NBitsServicio serv = new NBitsServicio();

        BigInteger numMaximo = serv.numeroMaximoEntero(n);

        if (numMaximo != null) {
            System.out.println("El numero mas grande con " + n + " bits es: " + numMaximo);
        } else {
            System.out.println("El numero de bits excede el rango");
        }
    }

}


/*
utiliza BigInteger para representar números enteros de cualquier tamaño, lo que permite al usuario ingresar 
un número de bits sin restricciones de límites. El número entero máximo se calcula mediante el método obtenerEnteroMaximo() 
en la clase Servicio utilizando la clase BigInteger. Luego, se muestra el resultado junto con su representación binaria 
utilizando el método toString(2) de BigInteger.
*/