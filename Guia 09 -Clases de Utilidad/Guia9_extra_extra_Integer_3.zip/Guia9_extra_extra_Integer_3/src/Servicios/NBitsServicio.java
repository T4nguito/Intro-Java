/*
Escribe un programa que encuentre el número entero más grande que 
se puede representar con n bits (donde n es un número entero que el usuario ingresa).

 */
package Servicios;

import java.math.BigInteger;

/**
 *
 * @author Salvador Caldarella
 */
public class NBitsServicio {

    /*
    utiliza BigInteger para representar números enteros de cualquier tamaño, lo que permite al usuario ingresar 
    un número de bits sin restricciones de límites. El número entero máximo se calcula mediante el método obtenerEnteroMaximo() 
    en la clase Servicio utilizando la clase BigInteger. Luego, se muestra el resultado junto con su representación binaria 
    utilizando el método toString(2) de BigInteger.
     */
    public BigInteger numeroMaximoEntero(int n) {
        
        String binary= Integer.toBinaryString(n);//convierte un entero, a su valor en bits.
        System.out.println("La representacion de "+n+" en bits seria: "+binary);// mostramos bits
        
        if (n <= 0) {
            throw new IllegalArgumentException("El número de bits debe ser positivo.");
        }
        
        // Calcula 2^n utilizando BigInteger
        BigInteger x = BigInteger.valueOf(2).pow(n);
        
        // Resta 1 al resultado para obtener el número entero máximo
        return x.subtract(BigInteger.ONE);

    }

}

//Metodo solo con Integer para numeros hasta 4 millones

//-----------------------------------------------------
//    public Integer numeroMaximoEntero(int n) {
//        String binary= Integer.toBinaryString(n);//convierte un entero, a su valor en bits.
//        System.out.println(binary);// mostramos bits
//        
//        
//        //Verificar si el numero de bits esta dentro del rango permitido.
//        if (n >= 1 && n <= Integer.SIZE) {
//            int numMaximo = (int) Math.pow(2, n) - 1;
//            return numMaximo;//devolver el numero maximo.
//        } else {
//
//            return null; //devolver null si el numero de bits esta fuera del rango.
//
//        }
//
//    }
