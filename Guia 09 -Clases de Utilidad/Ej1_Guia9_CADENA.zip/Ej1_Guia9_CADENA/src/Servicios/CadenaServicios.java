package Servicios;

import Entidades.Cadena;
import java.util.Scanner;

public class CadenaServicios {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    //Método mostrarVocales(), deberá contabilizar la cantidad de vocales que tiene la frase ingresada.
    public void mostrarVocales() {
        Cadena frase = new Cadena();
        int contador = 0;

        String letras = frase.getFrase().toLowerCase();

        for (int i = 0; i < letras.length(); i++) {
            char letra = letras.charAt(i);//charAt(i)retorna el caracter especificado en al posicion i
            if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
                contador++;
            }

        }
        System.out.println("La frase tiene " + contador + " vocales.");
    }

    //Método invertirFrase(), deberá invertir la frase ingresada y mostrarla por pantalla. Por ejemplo: Entrada: "casa blanca", Salida: "acnalb asac".
    public void invertirFrase(Cadena c1) {
        String frase = c1.getFrase();
        StringBuilder stringBuilder = new StringBuilder(frase);
        String fraseAlReves = stringBuilder.reverse().toString(); //stringBuilder.reverse().toString() retorna una cadena al reves
        System.out.println(fraseAlReves);

    }
//    Método vecesRepetido(String letra), recibirá un carácter ingresado por el usuario y contabilizar cuántas veces se repite el carácter en la frase, por ejemplo:
//Entrada: frase = "casa blanca". Salida: El carácter 'a' se repite 4 veces.

    public void vecesRepetido(Cadena c1) {

        String frase = c1.getFrase();
        System.out.println("Ingrese la letra a evaluar");
        char respuesta = leer.next().charAt(0);
        int contador = 0;

        for (int i = 0; i < frase.length(); i++) {
            char letras = frase.charAt(i);
            if (letras == respuesta) {
                contador++;

            }

        }

    }
   // Método compararLongitud(String frase), deberá comparar la longitud de la frase que compone la clase con otra nueva frase ingresada por el usuario.
    
    public void compararLongitud(Cadena c1){
        System.out.println("Ingrese una frase a comprarar");
        String nuevaFrase = leer.next();
        String fraseComparada = c1.getFrase();
        if (fraseComparada.length() == nuevaFrase.length()) {
            System.out.println("Las frases son iguales");
            
        }else
            System.out.println("No son iguales");
    
    }

//Método unirFrases(String frase), deberá unir la frase contenida en la clase Cadena con una nueva frase ingresada por el usuario y mostrar la frase resultante.
    public void unirFrases(Cadena c1){
       
        System.out.println("Ingrese una frase para sumar");
        String nuevaFrase = leer.next();
       //String espacio = " ";SI TIRA ERROR
        String fraseCompleta = c1.getFrase().concat(nuevaFrase);
        System.out.println(fraseCompleta);
    }
    //Método reemplazar(String letra), deberá reemplazar todas las letras “a” que se encuentren en la frase, 
   //por algún otro carácter seleccionado por el usuario y mostrar la frase resultante.
    public void reemplazar(Cadena c1){
        System.out.println("Ingrese un caracter para reeplazar 'a'");
        String letras= leer.next();
        String fraseReemplazada = c1.getFrase().replace("a", letras);
        System.out.println(fraseReemplazada);
    
    }
    //Método contiene(String letra), deberá comprobar si la frase contiene una letra que ingresa el usuario y devuelve verdadero si la contiene y falso si no.
    
    public void contiene(Cadena c1){
        String frase = c1.getFrase();
        boolean contiene = false;
        System.out.println("Ingrese una letra a buscar en la frase");
        String letra = leer.next();
        for (int i = 0; i < frase.length(); i++) {
            if (frase.substring(i,i+1).equalsIgnoreCase(letra)) {
                contiene= true;
                
            }
            
        }
        System.out.println(contiene);
           }

    
    }

    